const express = require("express");
const app = express();
// const mysql = require("mysql2");
const mysql = require("mysql2/promise");

app.use(express.json());


app.listen(3000, () =>{
});

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "trainee_app"
});


app.post("/adduser", async(req,res) =>{
	if(!req.body) return res.send({error:'Name,email and age is required'});
	if(!req.body.name) return res.send({error:'Name is required'});
	if(!req.body.email) return res.send({error:'Email is required'});
    if(!req.body.age) return res.send({error:'Age is required'});

	if(isNaN(req.body.age)) return res.send({error:'age should be in number'});

    var data = {
		name : req.body.name,
		email : req.body.email,
		age : req.body.age,
	}

	const [usercheck] = await db.query("SELECT * FROM user_table WHERE email = ?", req.body.email);
	if(usercheck.length > 0) return res.status(404).json({message:"Email already exit"});

	try{
		const [adduser] = await db.query('INSERT INTO user_table SET ?', data);
		if(adduser.affectedRows > 0) return res.status(200).json({message:"user Added!!"});
	}catch(err){
		return res.json(err);
	}

});

app.get("/getuser", async(req,res) => {
  try{ 
  	const [getuser] = await db.query("SELECT * FROM user_table");		
	 if(getuser.length > 0)	return res.json(getuser);
  }catch(err){
		return res.json(err);
	}
});

app.get("/getuser/:id", async(req,res) => {

	const [user] = await db.query("SELECT * FROM user_table WHERE  id = ?",req.params.id);
	if(user.length === 0) return res.json({message: "User not found"});

  try{ 
  	const [getuser] = await db.query("SELECT * FROM user_table WHERE id = ?",req.params.id);		
	 if(getuser)	return res.json(getuser);
  }catch(err){
		return res.json(err);
	}
});


app.delete("/deleteuser/:id", async(req,res) => {

	const [user] = await db.query("SELECT * FROM user_table WHERE  id = ?",req.params.id);
	if(user.length === 0) return res.json({message: "User not found"});

  try{ 
  	const [deleteuser] = await db.query("DELETE FROM user_table WHERE id=?",req.params.id);		
      if(deleteuser.affectedRows > 0)	return res.json({message:"User Deleted succefully!!"});
  }catch(err){
		return res.json(err);
	}
});


app.put("/updateuser/:id", async (req,res) => {

	const data = {}; 
    if(!req.body) return res.send({error:'Post field Name,email and age is required'});
	if(req.body.name != undefined) data['name'] = req.body.name;
	if(req.body.age != undefined) data['age'] = req.body.age; 
	if(req.body.age != undefined && isNaN(req.body.age)) return res.send({error:'age should be in number'});
	if(req.body.email != undefined) data['email'] = req.body.email;

	const [user] = await db.query("SELECT * FROM user_table WHERE  id = ?",req.params.id);
	if(user.length === 0) return res.json({message: "User not found"});

	const [emailCheck] = await db.query("SELECT * FROM user_table WHERE email = ? AND id != ?",[req.body.email,req.params.id]);
	if(emailCheck.length > 0) return res.status(400).json({message:"Email Already Exit"});

	const [updateuser] = await db.query("UPDATE user_table SET ? WHERE id = ?", [data, req.params.id]);
	if(updateuser.err) return res.status(400).json(updateuser.err);
	if(updateuser.affectedRows > 0) return res.json({message: "User updated!"});
});
